public class YesMan {
    public void query(String s){
        System.out.println("Yes!");
    }
}

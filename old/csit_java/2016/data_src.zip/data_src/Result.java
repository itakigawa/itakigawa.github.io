enum Result {WIN, LOSE, DRAW}

public class NoMan {
    public void query(String s){
        System.out.println("No!");
    }
}

public interface NameAvailable {
    public String getName();
}

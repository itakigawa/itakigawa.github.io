public class HelloWorld2 {
    public static void main(String[] args) {
        System.out.printf("Args 1: %s, 2: %s\n",args[0],args[1]);
    }
}
